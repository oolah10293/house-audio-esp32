New Lite-On USB transport recovery firmware source (not the old firmware).
Arduino 2.0.14, XIAO ESP32S3; edit LocalNetworkConfig.h with your existing Wi-Fi credentials.
Upload with your proven Arduino --no-stub setup.
Changes: increased USB CBW and CSW timeouts, transport error preservation, bulk-only reset on transport errors.
Auto-play event identity retained. Physical hardware validation remains pending.
