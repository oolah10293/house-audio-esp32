Lite-On CD recovery: exact field-proven v0.2 baseline source.
Arduino ESP32 core 2.0.14; XIAO ESP32S3; use previously working --no-stub upload setup.
Edit HouseAudioCDInput/LocalNetworkConfig.h with your own home Wi-Fi credentials before compiling.
No new bootSession/discRevision auto-takeover; this is rollback for detection and CD audio path.
No physical regression test has yet been performed for this recovery package.
